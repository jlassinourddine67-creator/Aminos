const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
document.getElementById("particles").appendChild(canvas);

canvas.width = innerWidth;
canvas.height = innerHeight;

let particles = [];
for(let i=0;i<100;i++){
  particles.push({x:Math.random()*canvas.width,y:Math.random()*canvas.height,r:Math.random()*2+1,dx:Math.random()-0.5,dy:Math.random()-0.5});
}

function animate(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  particles.forEach(p=>{
    ctx.beginPath();
    ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
    ctx.fillStyle="#38bdf8";
    ctx.fill();
    p.x+=p.dx;
    p.y+=p.dy;
  });
  requestAnimationFrame(animate);
}
animate();